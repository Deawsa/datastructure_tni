# Product Search System (หัวข้อ 09: ระบบค้นหาสินค้า แบบ Shopee / Lazada)

Java + Eclipse | มี 2 โหมด: **GUI (Swing)** และ **Terminal** | ใช้คลาสค้นหาชุดเดียวกันทั้งสองโหมด

## วิธีรันใน Eclipse
File > Import > General > **Existing Projects into Workspace** > เลือกโฟลเดอร์ `ProductSearchSystem` > Finish
คลิกขวาไฟล์ที่ต้องการ > Run As > **Java Application** (ต้องรันจากโฟลเดอร์โปรเจกต์ เพราะอ่านไฟล์ใน `data/`)

| ไฟล์ที่รัน | ใช้ทำอะไร | Login |
|---|---|---|
| `src/productsearch/TerminalMain.java` | **Demo แบบ Terminal** (ข้อ 2 ใน Scope) | `admin` / `admin1234` |
| `src/productsearch/Main.java` | Demo แบบ GUI | `admin` / `admin1234` |
| `src/productsearch/BigOBenchmark.java` | ทดลองพิสูจน์ Big-O ด้วย n = 1,000 / 10,000 / 100,000 | - |

ตัวอย่างผลลัพธ์ Terminal จริงอยู่ที่ `docs/terminal_demo_output.txt`

---

## ตรงกับ Scope & Requirement ทั้ง 5 ข้อ

| ข้อ | Scope | ทำไว้ที่ |
|---|---|---|
| 1 | ศึกษาการทำงานของระบบจริง | หัวข้อ "1." ด้านล่าง |
| 2 | Demo แบบ Terminal | `TerminalMain.java` |
| 3 | วิเคราะห์ Big-O คนละ 1 ฟีเจอร์ | หัวข้อ "3." + `BigOBenchmark.java` + แสดง Big-O ใต้ผลลัพธ์ทุกครั้ง |
| 4 | (พิเศษ) จุดพัฒนา + Demo ไม่มีบั๊ก | หัวข้อ "4." + `IndexedNameSearch.java` (Terminal เมนู 8, GUI ติ๊ก "Improved") |
| 5 | ถาม-ตอบ | หัวข้อ "5." |

---

## 1. ศึกษาระบบจริง (Shopee / Lazada) เทียบกับระบบที่เราทำ

Shopee/Lazada ไม่เปิดเผยสถาปัตยกรรมภายใน สิ่งที่สรุปได้เป็นแนวทางทั่วไปของ e-commerce search:

| ส่วนของระบบจริง | แนวคิดทั่วไป | ในโปรเจกต์เรา |
|---|---|---|
| ค้นด้วยคำ (keyword) | search engine แบบ **Inverted Index** (เช่น Elasticsearch/Solr) : คำ -> รายการสินค้า | ฟีเจอร์ 1 ใช้ Linear Search แบบพื้นฐาน, ส่วนพัฒนาใช้ Inverted Index จริง |
| กรองหมวดหมู่/ช่วงราคา (facet filter) | ดัชนีแยกตาม field แล้วกรอง | ฟีเจอร์ 3: HashMap หมวด + Binary Search ราคา |
| เปิดสินค้าด้วยรหัส | key lookup ใน database/index | ฟีเจอร์ 2: Binary Search |
| เรียงลำดับ (ราคา/ขายดี/เรตติ้ง) | ranking + sort | ช่อง Sort (Collections.sort) |
| ตะกร้า + เช็กสต็อก | cart service | Add to Cart / View Cart |
| ส่วนที่เราไม่ทำ | ranking ซับซ้อน, แก้คำผิด, autocomplete, personalization, โฆษณา | ตัดออกเพราะอยู่นอกขอบเขต |

## 2. Demo แบบ Terminal
รัน `TerminalMain` แล้วจะได้เมนู: 1 ค้นชื่อ, 2 ค้น ID, 3 กรองหมวด+ราคา, 4 แสดงทั้งหมด, 5 ตั้งค่า Sort,
6 เพิ่มตะกร้า, 7 ดูตะกร้า, 8 **[Bonus] เทียบ Linear vs Inverted Index**, 9 **Big-O benchmark**, 0 ออก
ทุกการค้นหาจะพิมพ์ Data structure / Algorithm / **Big-O** / Comparisons / Time ใต้ตาราง

## 3. วิเคราะห์ Big-O (คนละ 1 ฟีเจอร์)

n = จำนวนสินค้าทั้งหมด, k = สินค้าในหมวดนั้น, m = จำนวนผลลัพธ์, L = ความยาวชื่อสินค้า (ค่าเล็ก ถือเป็นค่าคงที่)

### ฟีเจอร์ 1: ค้นด้วยชื่อ — `NameSearch` (ArrayList + Linear Search)
- วน for 1 รอบ ตรวจชื่อทีละชิ้น (`products.get(i).getName().contains(word)`) งานต่อชิ้น ~ O(L) = คงที่
- **Best = Average = Worst = O(n)** เพราะต้องเก็บ "ทุกชิ้นที่ตรง" จึงหยุดก่อนไม่ได้ (ต่างจากการหาชิ้นเดียว)
- Space: O(1) เพิ่มเติม + O(m) เก็บผลลัพธ์
- ทดลองจริง: n = 1,000 -> 1,000 ครั้ง | 10,000 -> 10,000 | 100,000 -> 100,000 (เพิ่มตาม n)

### ฟีเจอร์ 2: ค้นด้วยรหัสสินค้า — `IdSearch` (Sorted Array + Binary Search)
- แต่ละรอบตัดช่วงค้นหาเหลือครึ่งเดียว: n -> n/2 -> n/4 ... -> 1 ใช้ log2(n) รอบ
- **Best O(1)** (เจอที่ตำแหน่งกลาง), **Average/Worst O(log n)**
- ต้นทุนเตรียมข้อมูล: เรียงครั้งเดียว O(n log n) (แต่ถ้าเพิ่มสินค้าใหม่ต้องแทรกให้ยังเรียง = O(n))
- ทดลองจริง (ค้น ID ที่ไม่มี = กรณีแย่สุด): n = 1,000 -> 10 | 10,000 -> 14 | 100,000 -> 17 (n โต 10 เท่า เพิ่มแค่ ~3)

### ฟีเจอร์ 3: กรองหมวดหมู่ + ช่วงราคา — `CategoryPriceFilter` (HashMap + Binary Search)
- หาหมวดด้วย HashMap: **O(1)** เฉลี่ย
- หาตำแหน่งราคาเริ่มต้นด้วย Binary Search (Lower Bound): **O(log k)**
- ไล่ต่อจนราคาเกิน max: **O(m)** (ข้อมูลเรียงตามราคาแล้ว จึงหยุดได้ทันที)
- รวม **O(1 + log k + m)**; ถ้าเลือก "All" ต้องทำซ้ำทุกหมวด (c หมวด) = O(c · log k + m)
- เตรียมข้อมูล: จัดกลุ่ม O(n) + เรียงราคา O(n log n) ครั้งเดียว | Space O(n)
- ทดลองจริง: n = 1,000 -> 9 | 10,000 -> 15 | 100,000 -> 39 ครั้ง (ช่วงราคาเดียวกัน, m = 0 / 2 / 24)

### ช่อง Sort (ใช้ร่วมทุกฟีเจอร์)
`Collections.sort` บนผลลัพธ์ที่ได้ = O(m log m)

## 4. (พิเศษ) จุดพัฒนาของระบบ + Demo

**ปัญหา:** ฟีเจอร์ 1 เป็น O(n) ถ้ามีสินค้าล้านชิ้น ทุกการกดค้นหาต้องไล่ล้านรอบ
**แนวทางแก้:** `IndexedNameSearch` สร้าง Inverted Index ครั้งเดียวตอนเปิดโปรแกรม (คำ/ต้นคำ -> รายการสินค้า) แล้วค้นด้วย Hash lookup
- ค้นหา: **O(w + m)** (w = จำนวนคำที่พิมพ์, m = ขนาดรายการที่สั้นที่สุดของคำที่พิมพ์) แทน O(n)
- ผลทดลอง (`BigOBenchmark`, คำค้นที่เจอ 1 ชิ้น): n = 1,000 / 10,000 / 100,000 -> Linear 1,000 / 10,000 / 100,000 ครั้ง แต่ Inverted Index **3 ครั้งเท่าเดิม**
- ตรวจความถูกต้อง: ทดสอบ 319 คำค้นกับข้อมูลจริง ผลตรงกับการค้นแบบตรวจเองทุกคำ
- **ข้อแลกเปลี่ยน (พูดก่อนถูกถาม):**
  1. ใช้หน่วยความจำเพิ่ม O(n·L) และต้องสร้างดัชนีตอนเริ่ม
  2. จับคู่ได้เฉพาะ "ต้นคำ": พิมพ์ `blue` เจอ Bluetooth แต่ `tooth` ไม่เจอ (Linear Search เจอ)
  3. คำที่พบบ่อยมาก (เช่น `wireless`) m ใหญ่ ต้นทุนก็โตตาม m (แต่ไม่เกิน n)
  4. เพิ่ม/ลบสินค้าต้องอัปเดตดัชนีด้วย
- ลองดู: Terminal เมนู 8 หรือ GUI Tab 1 ติ๊ก **Improved: Inverted Index**
- แนวทางพัฒนาต่อ (ยังไม่ได้ทำ): Trie สำหรับ autocomplete, จัดอันดับตามความเกี่ยวข้อง/ยอดขาย, รองรับคำผิด (fuzzy), เก็บข้อมูลใน database แทนไฟล์ txt

## 5. เตรียมถาม-ตอบ (รายบุคคล)
- **ทำไมฟีเจอร์ 1 ไม่ใช้ Binary Search?** ค้นแบบ "มีคำนี้อยู่ในชื่อ" (contains) ใช้ลำดับ/การเรียงช่วยไม่ได้ จึงต้องไล่ทุกชิ้น
- **Binary Search ใช้ได้เมื่อไหร่?** เมื่อข้อมูลเรียงแล้ว (เราเรียง id ไว้ก่อนตอนโหลด)
- **ถ้า id ไม่เรียงล่ะ?** Binary Search จะให้ผลผิด ต้องเรียงก่อน หรือใช้ Linear Search / HashMap
- **ทำไมฟีเจอร์ 3 ต้องเรียงราคาในแต่ละหมวดไว้ก่อน?** เพื่อให้ Binary Search หาจุดเริ่มช่วงราคาได้ และหยุดไล่เมื่อราคาเกิน max
- **HashMap แย่สุดเป็นเท่าไร?** O(k) ถ้า hash ชนกันหมด แต่เฉลี่ย O(1)
- **Big-O ไม่บอกเวลาจริงใช่ไหม?** ใช่ บอกอัตราการโตตาม n; ตอน n=45 ต่างกันแทบไม่เห็น จึงทำ `BigOBenchmark` ที่ n ใหญ่ขึ้น
- **Linear Search ค้นเจอแล้วทำไมไม่หยุด?** เพราะเราต้องการทุกชิ้นที่ตรง ไม่ใช่ชิ้นแรกชิ้นเดียว
- **จุดพัฒนาคืออะไร ข้อเสียคืออะไร?** ดูหัวข้อ 4

## โครงสร้างไฟล์
```
src/productsearch/
  Product, SearchResult, ProductStore          ข้อมูลและการโหลดไฟล์
  NameSearch / IdSearch / CategoryPriceFilter  3 ฟีเจอร์หลัก
  IndexedNameSearch                            จุดพัฒนา (Inverted Index)
  BigOBenchmark                                พิสูจน์ Big-O
  TerminalMain                                 Demo แบบ Terminal
  Main, LoginWindow, MainWindow, CartDialog    Demo แบบ GUI
data/products.txt (45 ชิ้น), data/users.txt
```
