package productsearch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.function.Supplier;

/**
 * พิสูจน์ Big-O ด้วยการนับ "จำนวนครั้งที่เปรียบเทียบ" จริง เมื่อ n เพิ่มขึ้น 10 เท่า
 *  - Linear Search   : เพิ่มตาม n                  -> O(n)
 *  - Binary Search   : เพิ่มทีละ ~3 (log2 10)       -> O(log n)
 *  - Hash + Binary   : ~ log k + m
 *  - Inverted Index  : คำค้นที่เจอน้อย (m = 1) แทบไม่เปลี่ยนตาม n -> O(w + m)
 * รันได้ที่ไฟล์นี้โดยตรง หรือจากเมนูใน TerminalMain
 */
public class BigOBenchmark {
    private static final String[] ADJ = {"Wireless", "Portable", "Smart", "Mini", "Classic", "Premium",
            "Lightweight", "Compact", "Durable", "Silent", "Folding", "Rechargeable"};
    private static final String[] NOUN = {"Speaker", "Charger", "Backpack", "Lamp", "Bottle", "Keyboard",
            "Camera", "Headset", "Shoes", "Wallet", "Blender", "Notebook", "Tripod", "Mouse"};
    private static final String[] CAT = {"Electronics", "Fashion", "Home & Living", "Beauty", "Sports", "Books", "Toys"};

    public static void main(String[] args) {
        run();
    }

    public static void run() {
        int[] sizes = {1000, 10000, 100000};
        System.out.println("BIG-O BENCHMARK  (cmp = real number of comparisons, ms = median of 21 runs)");
        System.out.println("Name = \"zephyr gadget\" (1 match) | ID = not found (worst case) | Filter = Fashion, price 500-510");
        String line = "------------------------------------------------------------------------------------------------";
        System.out.println(line);
        System.out.println(String.format("%-9s | %-22s | %-22s | %-22s | %-22s",
                "n", "Linear (name)", "Binary (ID)", "Hash+Binary (filter)", "Inverted Index (name)"));
        System.out.println(String.format("%-9s | %-22s | %-22s | %-22s | %-22s",
                "", "cmp / ms", "cmp / ms (log2 n)", "cmp / ms  [m]", "cmp / ms"));
        System.out.println(line);

        for (int n : sizes) {
            ArrayList<Product> data = generate(n);
            NameSearch linear = new NameSearch(data);
            IdSearch binary = new IdSearch(data);
            CategoryPriceFilter hash = new CategoryPriceFilter(data);
            IndexedNameSearch inverted = new IndexedNameSearch(data);
            final String missingId = "P9999999"; // ไม่มีในข้อมูล = กรณีแย่สุดของ Binary Search

            SearchResult a = measure(() -> linear.search("zephyr gadget"));
            SearchResult b = measure(() -> binary.search(missingId));
            SearchResult c = measure(() -> hash.search("Fashion", 500, 510));
            SearchResult d = measure(() -> inverted.search("zephyr gadget"));

            double log2 = Math.log(n) / Math.log(2);
            System.out.println(String.format("%-9d | %-22s | %-22s | %-22s | %-22s",
                    n,
                    a.comparisons + " / " + fmt(a.millis),
                    b.comparisons + " / " + fmt(b.millis) + "  (" + String.format("%.1f", log2) + ")",
                    c.comparisons + " / " + fmt(c.millis) + "  [" + c.products.size() + "]",
                    d.comparisons + " / " + fmt(d.millis)));
            if (a.products.size() != d.products.size()) {
                System.out.println("          note: Linear found " + a.products.size() + ", Inverted Index found "
                        + d.products.size());
            }
        }
        System.out.println(line);
        System.out.println("n x10  ->  Linear x10 | Binary +~3 | Hash+Binary +~3 (plus m) | Inverted Index ~constant (m = 1)");
        System.out.println("Note: a very common keyword (e.g. \"wireless\") has a large m, so Inverted Index cost grows with m (still <= n).");
    }

    private static String fmt(double ms) {
        return String.format("%.4f", ms);
    }

    /** รันหลายรอบแล้วเอาค่ากลางของเวลา (ลดผลของ JIT warm-up) */
    private static SearchResult measure(Supplier<SearchResult> task) {
        double[] times = new double[21];
        SearchResult last = null;
        for (int i = 0; i < times.length; i++) {
            last = task.get();
            times[i] = last.millis;
        }
        Arrays.sort(times);
        return new SearchResult(last.products, last.comparisons,
                (long) (times[times.length / 2] * 1_000_000), last.dataSize,
                last.dataStructure, last.algorithm, last.bigO);
    }

    /** สร้างสินค้าจำลอง n ชิ้น (seed คงที่ ผลซ้ำได้) สลับลำดับ id */
    static ArrayList<Product> generate(int n) {
        Random rnd = new Random(42);
        ArrayList<Product> list = new ArrayList<>(n);
        for (int i = 1; i < n; i++) {
            String name = ADJ[rnd.nextInt(ADJ.length)] + " " + NOUN[rnd.nextInt(NOUN.length)]
                    + " " + (rnd.nextInt(900) + 100);
            list.add(new Product(String.format("P%07d", i), name, CAT[rnd.nextInt(CAT.length)],
                    50 + rnd.nextInt(4950), 3 + rnd.nextInt(21) / 10.0, rnd.nextInt(10000), rnd.nextInt(200)));
        }
        // สินค้าที่มีคำเฉพาะ 1 ชิ้น ไว้ทดสอบคำค้นที่เจอน้อย (m = 1)
        list.add(new Product(String.format("P%07d", n), "Zephyr Gadget", "Electronics", 999, 4.5, 10, 5));
        Collections.shuffle(list, rnd);
        return list;
    }
}
