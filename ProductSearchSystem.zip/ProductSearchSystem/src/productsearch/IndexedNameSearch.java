package productsearch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;

/**
 * [BONUS - จุดพัฒนา] ค้นหาด้วยชื่อแบบ Inverted Index (แนวคิดเดียวกับ search engine จริง)
 *
 * ปัญหาของ Linear Search (NameSearch): ต้องไล่ทุกสินค้า O(n) ทุกครั้งที่ค้น
 * แนวทางแก้: สร้าง "ดัชนี" ไว้ล่วงหน้า 1 ครั้ง  คำ(prefix) -> รายการสินค้าที่มีคำนั้นในชื่อ
 *   ตัวอย่าง  "blue", "bluet", ... "bluetooth" -> [Earbuds, Speaker]
 *
 *  - โครงสร้างข้อมูล : HashMap<String, ArrayList<Product>>  (Inverted Index)
 *  - อัลกอริทึม      : Hash lookup ต่อ 1 คำค้น แล้วตรวจเฉพาะสินค้าในรายการที่สั้นที่สุด (กรณีค้นหลายคำ)
 *  - Big-O ค้นหา     : O(w + m)  w = จำนวนคำที่พิมพ์, m = ขนาดรายการที่สั้นที่สุดของคำที่พิมพ์
 *                      ไม่ขึ้นกับ n โดยตรง (ถ้าคำนั้นเจอในสินค้าจำนวนมาก m ก็มาก แต่ไม่เกิน n) (สร้างดัชนีครั้งเดียว O(n * L), L = ความยาวชื่อ)
 *  - ข้อแลกเปลี่ยน   : ใช้หน่วยความจำเพิ่ม และจับคู่ได้เฉพาะ "ต้นคำ" (prefix) ของแต่ละคำในชื่อ
 *                      เช่น "blue" เจอ Bluetooth แต่ "tooth" ไม่เจอ (Linear Search เจอ)
 */
public class IndexedNameSearch {
    private final HashMap<String, ArrayList<Product>> index = new HashMap<>();
    private final int total;

    public IndexedNameSearch(ArrayList<Product> products) {
        total = products.size();
        for (Product p : products) {
            // prefix ทั้งหมดของทุกคำในชื่อ (LinkedHashSet กันสินค้าซ้ำใน key เดียวกัน)
            LinkedHashSet<String> keys = new LinkedHashSet<>();
            for (String word : tokenize(p.getName())) {
                for (int len = 1; len <= word.length(); len++) {
                    keys.add(word.substring(0, len));
                }
            }
            for (String key : keys) {
                ArrayList<Product> list = index.get(key);
                if (list == null) {
                    list = new ArrayList<>();
                    index.put(key, list);
                }
                list.add(p);
            }
        }
    }

    /** ตัดคำ: ตัวพิมพ์เล็ก และแยกด้วยอักขระที่ไม่ใช่ตัวอักษร/ตัวเลข */
    private static String[] tokenize(String text) {
        String t = text.toLowerCase().replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
        if (t.isEmpty()) return new String[0];
        return t.split(" ");
    }

    public SearchResult search(String keyword) {
        long start = System.nanoTime();
        int comparisons = 0;
        ArrayList<Product> found = new ArrayList<>();
        String[] words = tokenize(keyword);

        // ===== INVERTED INDEX LOOKUP: คำละ 1 ครั้ง (hash) =====
        ArrayList<ArrayList<Product>> lists = new ArrayList<>();
        boolean empty = words.length == 0;
        for (int i = 0; i < words.length && !empty; i++) {
            ArrayList<Product> postings = index.get(words[i]);
            comparisons++;
            if (postings == null) empty = true;
            else lists.add(postings);
        }

        if (!empty) {
            // เริ่มจากรายการที่ "สั้นที่สุด" แล้วตรวจว่าตรงกับคำที่เหลือไหม (ลดงานเมื่อค้นหลายคำ)
            int smallest = 0;
            for (int i = 1; i < lists.size(); i++) {
                if (lists.get(i).size() < lists.get(smallest).size()) smallest = i;
            }
            for (Product p : lists.get(smallest)) {
                comparisons++;
                String[] nameWords = tokenize(p.getName());
                boolean matchAll = true;
                for (String w : words) {
                    boolean hit = false;
                    for (String nw : nameWords) {
                        if (nw.startsWith(w)) { hit = true; break; }
                    }
                    if (!hit) { matchAll = false; break; }
                }
                if (matchAll) found.add(p);
            }
        }

        long nanos = System.nanoTime() - start;
        return new SearchResult(found, comparisons, nanos, total,
                "HashMap<Prefix, ArrayList> (Inverted Index)",
                "Inverted Index Lookup (smallest list first)",
                "O(w + m)");
    }
}
