package productsearch;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 * หน้าหลัก: ค้นหาสินค้าแบบ Shopee / Lazada
 * Tab 1 = ค้นหาด้วยชื่อ (Linear Search | ติ๊ก Improved = Inverted Index ซึ่งเป็นจุดพัฒนา)
 * Tab 2 = ค้นหาด้วยรหัสสินค้า (Binary Search)
 * Tab 3 = กรองหมวดหมู่ + ช่วงราคา (HashMap + Binary Search)
 */
public class MainWindow {
    private final JFrame frame;
    private final JTable table;
    private final DefaultTableModel model;
    private final JLabel lblStruct = new JLabel(" ");
    private final JLabel lblAlgo = new JLabel(" ");
    private final JLabel lblBigO = new JLabel(" ");
    private final JLabel lblStat = new JLabel(" ");
    private final JComboBox<String> cmbSort = new JComboBox<>(new String[] {
            "Sort: Default", "Price: Low to High", "Price: High to Low",
            "Best Selling", "Top Rated"});

    private final ProductStore store;
    private final NameSearch nameSearch;
    private final IndexedNameSearch indexedSearch;
    private final IdSearch idSearch;
    private final CategoryPriceFilter filter;
    private final LinkedHashMap<Product, Integer> cart = new LinkedHashMap<>();

    private SearchResult lastResult;

    // ช่องกรอกของแต่ละ Tab
    private final JTextField txtName = new JTextField(22);
    private final JCheckBox chkIndexed = new JCheckBox("Improved: Inverted Index");
    private final JTextField txtId = new JTextField(10);
    private final JComboBox<String> cmbCategory = new JComboBox<>();
    private final JTextField txtMin = new JTextField("0", 7);
    private final JTextField txtMax = new JTextField("100000", 7);

    public MainWindow() {
        store = new ProductStore("data/products.txt");
        try {
            store.load();
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "File not found: data/products.txt",
                    "Warning", JOptionPane.WARNING_MESSAGE);
        }
        nameSearch = new NameSearch(store.getProducts());
        indexedSearch = new IndexedNameSearch(store.getProducts());
        idSearch = new IdSearch(store.getProducts());
        filter = new CategoryPriceFilter(store.getProducts());

        cmbCategory.addItem(CategoryPriceFilter.ALL);
        for (String c : filter.getCategoryNames(store.getProducts())) cmbCategory.addItem(c);

        frame = new JFrame("Product Search System");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(920, 580);
        frame.setLocationRelativeTo(null);

        // ---------- ตาราง ----------
        model = new DefaultTableModel(
                new String[] {"ID", "Product", "Category", "Price (THB)", "Rating", "Sold", "Stock"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setRowHeight(24);
        table.getTableHeader().setReorderingAllowed(false);
        int[] widths = {60, 260, 110, 90, 60, 60, 60};
        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < widths.length; i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
            if (i != 1) table.getColumnModel().getColumn(i).setCellRenderer(center);
        }
        ((DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment(JLabel.CENTER);

        // ---------- ส่วนบน: Tab ค้นหา ----------
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("1. Search by Name", buildNameTab());
        tabs.addTab("2. Search by Product ID", buildIdTab());
        tabs.addTab("3. Category & Price Filter", buildFilterTab());

        JPanel sortRow = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        sortRow.add(cmbSort);
        JPanel top = new JPanel(new BorderLayout());
        top.add(tabs, BorderLayout.CENTER);
        top.add(sortRow, BorderLayout.SOUTH);

        // ---------- ส่วนล่าง: สถานะ + ปุ่ม ----------
        lblStruct.setFont(lblStruct.getFont().deriveFont(Font.BOLD));
        lblAlgo.setFont(lblAlgo.getFont().deriveFont(Font.BOLD));
        lblBigO.setFont(lblBigO.getFont().deriveFont(Font.BOLD));
        lblStat.setForeground(new Color(0x555555));
        JPanel info = new JPanel(new java.awt.GridLayout(4, 1));
        info.add(lblStruct);
        info.add(lblAlgo);
        info.add(lblBigO);
        info.add(lblStat);

        JButton btnAll = new JButton("Show All");
        JButton btnAddCart = new JButton("Add to Cart");
        JButton btnViewCart = new JButton("View Cart");
        JButton btnLogout = new JButton("Logout");
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(btnAll);
        buttons.add(btnAddCart);
        buttons.add(btnViewCart);
        buttons.add(btnLogout);

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        bottom.add(info, BorderLayout.CENTER);
        bottom.add(buttons, BorderLayout.EAST);

        JPanel root = new JPanel(new BorderLayout(0, 4));
        root.setBorder(BorderFactory.createEmptyBorder(6, 8, 0, 8));
        root.add(top, BorderLayout.NORTH);
        root.add(new JScrollPane(table), BorderLayout.CENTER);
        root.add(bottom, BorderLayout.SOUTH);
        frame.setContentPane(root);

        // ---------- Events ----------
        cmbSort.addActionListener(e -> { if (lastResult != null) showResult(lastResult); });
        btnAll.addActionListener(e -> showAll());
        btnAddCart.addActionListener(e -> addToCart());
        btnViewCart.addActionListener(e -> new CartDialog(frame, cart).setVisible(true));
        btnLogout.addActionListener(e -> {
            frame.dispose();
            new LoginWindow();
        });

        showAll();
        frame.setVisible(true);
    }

    // ================= Tab builders =================
    private JPanel buildNameTab() {
        JButton btn = new JButton("Search");
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        p.add(new JLabel("Product name:"));
        p.add(txtName);
        p.add(btn);
        p.add(clearButton());
        p.add(chkIndexed);
        p.add(hint("unchecked = Linear Search"));
        btn.addActionListener(e -> doNameSearch());
        txtName.addActionListener(e -> doNameSearch());
        return p;
    }

    private JPanel buildIdTab() {
        JButton btn = new JButton("Search");
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        p.add(new JLabel("Product ID (e.g. P012):"));
        p.add(txtId);
        p.add(btn);
        p.add(clearButton());
        p.add(hint("Binary Search on sorted array"));
        btn.addActionListener(e -> doIdSearch());
        txtId.addActionListener(e -> doIdSearch());
        return p;
    }

    private JPanel buildFilterTab() {
        JButton btn = new JButton("Filter");
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        p.add(new JLabel("Category:"));
        p.add(cmbCategory);
        p.add(new JLabel("Price from"));
        p.add(txtMin);
        p.add(new JLabel("to"));
        p.add(txtMax);
        p.add(btn);
        p.add(clearButton());
        p.add(hint("HashMap + Binary Search"));
        btn.addActionListener(e -> doFilter());
        return p;
    }

    private JButton clearButton() {
        JButton b = new JButton("Clear");
        b.addActionListener(e -> clearSearch());
        return b;
    }

    private JLabel hint(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(Color.GRAY);
        return l;
    }

    // ================= Actions =================
    private void doNameSearch() {
        if (txtName.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter a product name.");
            return;
        }
        if (chkIndexed.isSelected()) showResult(indexedSearch.search(txtName.getText()));
        else showResult(nameSearch.search(txtName.getText()));
    }

    private void doIdSearch() {
        if (txtId.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter a product ID.");
            return;
        }
        showResult(idSearch.search(txtId.getText()));
    }

    private void doFilter() {
        try {
            double min = Double.parseDouble(txtMin.getText().trim());
            double max = Double.parseDouble(txtMax.getText().trim());
            if (min > max) {
                JOptionPane.showMessageDialog(frame, "Minimum price must not exceed maximum price.");
                return;
            }
            showResult(filter.search((String) cmbCategory.getSelectedItem(), min, max));
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid price entered.");
        }
    }

    /** ล้างช่องค้นหาทุก Tab แล้วกลับไปแสดงสินค้าทั้งหมด */
    private void clearSearch() {
        txtName.setText("");
        chkIndexed.setSelected(false);
        txtId.setText("");
        cmbCategory.setSelectedIndex(0);   // CategoryPriceFilter.ALL
        txtMin.setText("0");
        txtMax.setText("100000");
        table.clearSelection();
        showAll();
    }

    private void showAll() {
        lastResult = new SearchResult(new ArrayList<>(store.getProducts()), 0, 0,
                store.getProducts().size(), "ArrayList", "-", "-");
        fillTable(lastResult.products);
        lblStruct.setText("Showing all products");
        lblAlgo.setText(" ");
        lblBigO.setText(" ");
        lblStat.setText("Results: " + lastResult.products.size());
    }

    private void showResult(SearchResult r) {
        lastResult = r;
        fillTable(r.products);
        lblStruct.setText("Data structure: " + r.dataStructure);
        lblAlgo.setText("Algorithm: " + r.algorithm);
        lblBigO.setText("Big-O: " + r.bigO);
        lblStat.setText("Results: " + r.products.size() + " of " + r.dataSize
                + "   |   Comparisons: " + r.comparisons
                + "   |   Time: " + String.format("%.4f", r.millis) + " ms");
        if (r.products.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "No products found.", "Search", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void fillTable(ArrayList<Product> list) {
        ArrayList<Product> sorted = new ArrayList<>(list);
        Comparator<Product> cmp = null;
        switch (cmbSort.getSelectedIndex()) {
            case 1: cmp = (a, b) -> Double.compare(a.getPrice(), b.getPrice()); break;
            case 2: cmp = (a, b) -> Double.compare(b.getPrice(), a.getPrice()); break;
            case 3: cmp = (a, b) -> Integer.compare(b.getSold(), a.getSold()); break;
            case 4: cmp = (a, b) -> Double.compare(b.getRating(), a.getRating()); break;
            default: break;
        }
        if (cmp != null) Collections.sort(sorted, cmp);

        model.setRowCount(0);
        for (Product p : sorted) {
            model.addRow(new Object[] {p.getId(), p.getName(), p.getCategory(),
                    String.format("%,.0f", p.getPrice()), p.getRating(), p.getSold(), p.getStock()});
        }
    }

    private void addToCart() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(frame, "Please select a product first!");
            return;
        }
        String id = (String) model.getValueAt(row, 0);
        Product target = null;
        for (Product p : store.getProducts()) {
            if (p.getId().equals(id)) { target = p; break; }
        }
        if (target == null) return;
        int inCart = cart.containsKey(target) ? cart.get(target) : 0;
        if (inCart >= target.getStock()) {
            JOptionPane.showMessageDialog(frame, "Out of stock!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        cart.put(target, inCart + 1);
        JOptionPane.showMessageDialog(frame, target.getName() + " added to cart!");
    }
}