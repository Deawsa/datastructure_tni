package productsearch;

import java.util.ArrayList;

/**
 * ฟีเจอร์ที่ 1: ค้นหาสินค้าด้วยชื่อ (Keyword)
 *  - โครงสร้างข้อมูล : ArrayList<Product>  (1 element = 1 Product)
 *  - อัลกอริทึม      : Linear Search (Sequential Search)
 *  - Big-O           : O(n) ทุกกรณีต้องไล่ครบทุกชิ้น เพราะต้องเก็บทุกสินค้าที่ "มีคำค้นอยู่ในชื่อ"
 */
public class NameSearch {
    private final ArrayList<Product> products;

    public NameSearch(ArrayList<Product> products) {
        this.products = products;
    }

    public SearchResult search(String keyword) {
        long start = System.nanoTime();
        int comparisons = 0;
        ArrayList<Product> found = new ArrayList<>();

        // แยกคำค้นเป็นหลายคำ (เหมือน Shopee/Lazada: ต้องเจอครบทุกคำ)
        String[] words = keyword.trim().toLowerCase().split("\\s+");

        // ===== LINEAR SEARCH: ไล่ทีละ index ตั้งแต่ 0 ถึง n-1 =====
        for (int i = 0; i < products.size(); i++) {
            comparisons++;
            String name = products.get(i).getName().toLowerCase();
            boolean matchAll = true;
            for (String w : words) {
                if (!name.contains(w)) {
                    matchAll = false;
                    break;
                }
            }
            if (matchAll) found.add(products.get(i));
        }

        long nanos = System.nanoTime() - start;
        return new SearchResult(found, comparisons, nanos, products.size(),
                "ArrayList", "Linear Search", "O(n)");
    }
}
