package productsearch;

/** ข้อมูลสินค้า 1 ชิ้น (1 element ใน ArrayList / Array / HashMap) */
public class Product {
    private final String id;
    private final String name;
    private final String category;
    private final double price;
    private final double rating;
    private final int sold;
    private int stock;

    public Product(String id, String name, String category, double price,
                   double rating, int sold, int stock) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.rating = rating;
        this.sold = sold;
        this.stock = stock;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
    public double getRating() { return rating; }
    public int getSold() { return sold; }
    public int getStock() { return stock; }

    /** รูปแบบไฟล์: id,name,category,price,rating,sold,stock */
    public static Product fromTextLine(String line) {
        String[] p = line.split(",");
        if (p.length < 7) return null;
        try {
            return new Product(p[0].trim(), p[1].trim(), p[2].trim(),
                    Double.parseDouble(p[3].trim()), Double.parseDouble(p[4].trim()),
                    Integer.parseInt(p[5].trim()), Integer.parseInt(p[6].trim()));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return id + " | " + name + " | " + category + " | " + price;
    }
}
