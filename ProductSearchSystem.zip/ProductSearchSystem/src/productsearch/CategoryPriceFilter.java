package productsearch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

/**
 * ฟีเจอร์ที่ 3: กรองสินค้าตามหมวดหมู่ + ช่วงราคา
 *  - โครงสร้างข้อมูล : HashMap<String, ArrayList<Product>>
 *                      key = ชื่อหมวดหมู่, value = รายการสินค้าในหมวดนั้น "เรียงตามราคา"
 *  - อัลกอริทึม      : Hash lookup (หาหมวด) + Binary Search (Lower Bound หาราคาเริ่มต้น)
 *                      แล้วไล่ต่อไปจนเกินราคาสูงสุด
 *  - Big-O           : O(1) หาหมวด + O(log k) หาจุดเริ่ม + O(m) ไล่ผลลัพธ์
 *                      (k = จำนวนสินค้าในหมวด, m = จำนวนสินค้าที่ตรงเงื่อนไข)
 */
public class CategoryPriceFilter {
    public static final String ALL = "All";

    private final HashMap<String, ArrayList<Product>> byCategory = new HashMap<>();
    private final int total;

    public CategoryPriceFilter(ArrayList<Product> products) {
        total = products.size();
        // เตรียมข้อมูล: จัดกลุ่มตามหมวด
        for (Product p : products) {
            String key = p.getCategory().toLowerCase();
            ArrayList<Product> list = byCategory.get(key);
            if (list == null) {
                list = new ArrayList<>();
                byCategory.put(key, list);
            }
            list.add(p);
        }
        // เรียงแต่ละหมวดตามราคา (น้อย -> มาก) เพื่อใช้ Binary Search
        for (ArrayList<Product> list : byCategory.values()) {
            Collections.sort(list, new Comparator<Product>() {
                @Override
                public int compare(Product a, Product b) {
                    return Double.compare(a.getPrice(), b.getPrice());
                }
            });
        }
    }

    /** ชื่อหมวดทั้งหมด (ไว้ใส่ ComboBox) */
    public ArrayList<String> getCategoryNames(ArrayList<Product> products) {
        ArrayList<String> names = new ArrayList<>();
        for (Product p : products) {
            if (!names.contains(p.getCategory())) names.add(p.getCategory());
        }
        Collections.sort(names);
        return names;
    }

    public SearchResult search(String category, double minPrice, double maxPrice) {
        long start = System.nanoTime();
        int[] comparisons = {0};
        ArrayList<Product> found = new ArrayList<>();

        if (category.equals(ALL)) {
            // ทุกหมวด: ทำซ้ำกับทุก key ใน HashMap
            for (Map.Entry<String, ArrayList<Product>> e : byCategory.entrySet()) {
                collect(e.getValue(), minPrice, maxPrice, found, comparisons);
            }
        } else {
            // ===== HASH LOOKUP: หาหมวดแบบ O(1) =====
            ArrayList<Product> list = byCategory.get(category.toLowerCase());
            comparisons[0]++;
            if (list != null) collect(list, minPrice, maxPrice, found, comparisons);
        }

        long nanos = System.nanoTime() - start;
        return new SearchResult(found, comparisons[0], nanos, total,
                "HashMap<Category, ArrayList> (sorted by price)",
                "Hash Lookup + Binary Search (Lower Bound)",
                "O(1) + O(log k) + O(m)");
    }

    /** list เรียงตามราคาแล้ว: หา index แรกที่ price >= min ด้วย Binary Search แล้วไล่จนเกิน max */
    private void collect(ArrayList<Product> list, double min, double max,
                         ArrayList<Product> out, int[] comparisons) {
        // ===== BINARY SEARCH (Lower Bound) =====
        int low = 0;
        int high = list.size();
        while (low < high) {
            int mid = (low + high) / 2;
            comparisons[0]++;
            if (list.get(mid).getPrice() < min) low = mid + 1;
            else high = mid;
        }
        // ไล่จากจุดเริ่ม จนราคาเกิน max (ข้อมูลเรียงแล้ว จึงหยุดได้ทันที)
        for (int i = low; i < list.size(); i++) {
            comparisons[0]++;
            if (list.get(i).getPrice() > max) break;
            out.add(list.get(i));
        }
    }
}
