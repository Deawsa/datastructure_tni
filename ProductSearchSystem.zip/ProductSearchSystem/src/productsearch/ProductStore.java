package productsearch;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/** โหลดสินค้าจากไฟล์ data/products.txt เข้า ArrayList (ข้อมูลหลัก) */
public class ProductStore {
    private final ArrayList<Product> products = new ArrayList<>();
    private final String filePath;

    public ProductStore(String filePath) {
        this.filePath = filePath;
    }

    public void load() throws FileNotFoundException {
        products.clear();
        Scanner sc = new Scanner(new File(filePath), "UTF-8");
        while (sc.hasNextLine()) {
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            Product p = Product.fromTextLine(line);
            if (p != null) products.add(p);
        }
        sc.close();
    }

    public ArrayList<Product> getProducts() {
        return products;
    }
}
