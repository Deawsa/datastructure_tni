package productsearch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

/**
 * ฟีเจอร์ที่ 2: ค้นหาสินค้าด้วยรหัสสินค้า (Product ID)
 *  - โครงสร้างข้อมูล : Array Product[] ที่ "เรียงตาม id" ไว้ล่วงหน้า (เตรียมครั้งเดียวตอนโหลด)
 *  - อัลกอริทึม      : Binary Search (แบ่งครึ่งช่วงค้นหาทีละรอบ)
 *  - Big-O           : O(log n) ในการค้นหา  (การเรียงตอนเตรียมข้อมูล O(n log n) ทำครั้งเดียว)
 */
public class IdSearch {
    private final Product[] sorted;

    public IdSearch(ArrayList<Product> products) {
        // เตรียมข้อมูล: คัดลอกแล้วเรียงตาม id (ไฟล์ข้อมูลไม่ได้เรียงมา)
        sorted = products.toArray(new Product[0]);
        Arrays.sort(sorted, new Comparator<Product>() {
            @Override
            public int compare(Product a, Product b) {
                return a.getId().compareTo(b.getId());
            }
        });
    }

    public SearchResult search(String id) {
        long start = System.nanoTime();
        int comparisons = 0;
        String target = id.trim().toUpperCase();
        ArrayList<Product> found = new ArrayList<>();

        // ===== BINARY SEARCH =====
        int low = 0;
        int high = sorted.length - 1;
        while (low <= high) {
            int mid = (low + high) / 2;          // ตรวจตำแหน่งกึ่งกลาง
            comparisons++;
            int cmp = sorted[mid].getId().compareTo(target);
            if (cmp == 0) {                      // เจอแล้ว
                found.add(sorted[mid]);
                break;
            } else if (cmp < 0) {
                low = mid + 1;                   // ทิ้งครึ่งซ้าย
            } else {
                high = mid - 1;                  // ทิ้งครึ่งขวา
            }
        }

        long nanos = System.nanoTime() - start;
        return new SearchResult(found, comparisons, nanos, sorted.length,
                "Sorted Array (by ID)", "Binary Search", "O(log n)");
    }
}
