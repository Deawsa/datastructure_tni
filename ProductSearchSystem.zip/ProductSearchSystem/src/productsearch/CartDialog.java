package productsearch;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/** ตะกร้าสินค้าแบบง่าย: เก็บใน LinkedHashMap<Product, จำนวน> */
public class CartDialog extends JDialog {
    private final LinkedHashMap<Product, Integer> cart;
    private final DefaultTableModel model;
    private final JLabel lblTotal = new JLabel();

    public CartDialog(Frame owner, LinkedHashMap<Product, Integer> cart) {
        super(owner, "Cart", true);
        this.cart = cart;

        model = new DefaultTableModel(new String[] {"ID", "Product", "Price", "Qty", "Subtotal"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(model);
        table.getTableHeader().setReorderingAllowed(false);
        table.getColumnModel().getColumn(1).setPreferredWidth(220);

        JButton btnRemove = new JButton("Remove Selected");
        JButton btnClear = new JButton("Clear Cart");
        JButton btnClose = new JButton("Close");

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.add(lblTotal);
        bottom.add(btnRemove);
        bottom.add(btnClear);
        bottom.add(btnClose);

        setLayout(new BorderLayout(6, 6));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        btnRemove.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Select an item to remove.");
                return;
            }
            String id = (String) model.getValueAt(row, 0);
            Product target = null;
            for (Product p : cart.keySet()) {
                if (p.getId().equals(id)) target = p;
            }
            if (target != null) cart.remove(target);
            refresh();
        });
        btnClear.addActionListener(e -> { cart.clear(); refresh(); });
        btnClose.addActionListener(e -> dispose());

        refresh();
        setSize(620, 340);
        setLocationRelativeTo(owner);
    }

    private void refresh() {
        model.setRowCount(0);
        double total = 0;
        for (Map.Entry<Product, Integer> e : cart.entrySet()) {
            Product p = e.getKey();
            int qty = e.getValue();
            double sub = p.getPrice() * qty;
            total += sub;
            model.addRow(new Object[] {p.getId(), p.getName(), String.format("%,.2f", p.getPrice()), qty, String.format("%,.2f", sub)});
        }
        lblTotal.setText("Total: " + String.format("%,.2f", total) + " THB   ");
    }
}
