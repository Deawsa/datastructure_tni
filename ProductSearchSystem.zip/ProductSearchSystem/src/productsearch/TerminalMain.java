package productsearch;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * Demo แบบ Terminal ของ Product Search System
 * จุดเริ่มโปรแกรม: Run As > Java Application ที่ไฟล์นี้ (ต้องรันจากโฟลเดอร์รากของโปรเจกต์ เพื่อให้เจอโฟลเดอร์ data/)
 *
 * ใช้คลาสค้นหาตัวเดิมทั้งหมด (NameSearch / IdSearch / CategoryPriceFilter) ไม่ได้เขียนอัลกอริทึมใหม่
 */
public class TerminalMain {
    private static final Scanner IN = new Scanner(System.in, "UTF-8");
    private static final String LINE =
            "--------------------------------------------------------------------------------------";

    private static ProductStore store;
    private static NameSearch nameSearch;
    private static IndexedNameSearch indexedSearch;
    private static IdSearch idSearch;
    private static CategoryPriceFilter filter;
    private static final LinkedHashMap<Product, Integer> cart = new LinkedHashMap<>();

    private static final String[] SORT_NAMES = {
        "Default", "Price: Low to High", "Price: High to Low", "Best Selling", "Top Rated"};
    private static int sortMode = 0;

    /** ใช้โยนออกจาก menu loop เมื่อ input หมด (เช่น กด Ctrl+D / pipe ไฟล์จบ) */
    private static class EndOfInput extends RuntimeException {
        private static final long serialVersionUID = 1L;
    }

    public static void main(String[] args) {
        store = new ProductStore("data/products.txt");
        try {
            store.load();
        } catch (FileNotFoundException e) {
            System.out.println("Database file not found: data/products.txt");
            System.out.println("(Run from the project root folder so that the data/ folder can be found.)");
            return;
        }
        try {
            if (!login()) return;
            nameSearch = new NameSearch(store.getProducts());
            indexedSearch = new IndexedNameSearch(store.getProducts());
            idSearch = new IdSearch(store.getProducts());
            filter = new CategoryPriceFilter(store.getProducts());
            menuLoop();
        } catch (EndOfInput e) {
            System.out.println();
        }
        System.out.println("Goodbye!");
    }

    // ================= Input helpers =================
    private static String ask(String prompt) {
        System.out.print(prompt);
        if (!IN.hasNextLine()) throw new EndOfInput();
        return IN.nextLine().trim();
    }

    private static int readInt(String prompt, int min, int max) {
        while (true) {
            String s = ask(prompt);
            try {
                int v = Integer.parseInt(s);
                if (v >= min && v <= max) return v;
            } catch (NumberFormatException e) {
                // ตกลงไปแสดงข้อความเตือนด้านล่าง
            }
            System.out.println("  Please enter a number between " + min + " and " + max + ".");
        }
    }

    // ================= Login =================
    private static boolean login() {
        System.out.println("=== Product Search System (Terminal) ===");
        for (int attempt = 1; attempt <= 3; attempt++) {
            String user = ask("UserID  : ");
            String pass = ask("Password: ");
            if (user.isEmpty() || pass.isEmpty()) {
                System.out.println("Please fill in your UserID and Password.\n");
                continue;
            }
            if (checkUser(user, pass)) {
                System.out.println("Login successful.\n");
                return true;
            }
            System.out.println("Invalid UserID or Password. (" + attempt + "/3)\n");
        }
        System.out.println("Too many failed attempts.");
        return false;
    }

    private static boolean checkUser(String user, String pass) {
        try (Scanner sc = new Scanner(new File("data/users.txt"), "UTF-8")) {
            while (sc.hasNextLine()) {
                String[] p = sc.nextLine().split(",");
                if (p.length == 2 && p[0].trim().equals(user) && p[1].trim().equals(pass)) return true;
            }
        } catch (FileNotFoundException e) {
            System.out.println("Database file not found: data/users.txt");
        }
        return false;
    }

    // ================= Menu =================
    private static void menuLoop() {
        while (true) {
            System.out.println("========== MENU ==========");
            System.out.println(" 1. Search by name              [Linear Search]");
            System.out.println(" 2. Search by product ID        [Binary Search]");
            System.out.println(" 3. Filter by category + price  [Hash + Binary Search]");
            System.out.println(" 4. Show all products");
            System.out.println(" 5. Sort setting (current: " + SORT_NAMES[sortMode] + ")");
            System.out.println(" 6. Add to cart");
            System.out.println(" 7. View cart (remove / clear)   [items in cart: " + cart.size() + "]");
            System.out.println(" 8. [Bonus] Compare Linear Search vs Inverted Index");
            System.out.println(" 9. Big-O benchmark (n = 1,000 / 10,000 / 100,000)");
            System.out.println(" 0. Exit");
            int choice = readInt("Select > ", 0, 9);
            System.out.println();
            switch (choice) {
                case 1: doNameSearch(); break;
                case 2: doIdSearch(); break;
                case 3: doFilter(); break;
                case 4: showAll(); break;
                case 5: chooseSort(); break;
                case 6: addToCart(); break;
                case 7: viewCart(); break;
                case 8: compareName(); break;
                case 9: BigOBenchmark.run(); break;
                default: return;
            }
            System.out.println();
        }
    }

    // ================= Actions =================
    private static void doNameSearch() {
        String kw = ask("Product name (keyword, multiple words allowed): ");
        if (kw.isEmpty()) {
            System.out.println("Please enter a product name.");
            return;
        }
        showResult(nameSearch.search(kw));
    }

    /** Bonus: เปรียบเทียบอัลกอริทึมเดิมกับที่พัฒนา ด้วยคำค้นเดียวกัน */
    private static void compareName() {
        String kw = ask("Keyword to compare (e.g. wireless): ");
        if (kw.isEmpty()) {
            System.out.println("Please enter a keyword.");
            return;
        }
        SearchResult a = nameSearch.search(kw);
        SearchResult b = indexedSearch.search(kw);
        System.out.println(String.format("%-34s %-16s %12s %12s %5s", "Method", "Big-O", "Comparisons", "Time (ms)", "Found"));
        System.out.println(LINE);
        System.out.println(String.format("%-34s %-16s %12d %12.4f %5d", a.algorithm, a.bigO, a.comparisons, a.millis, a.products.size()));
        System.out.println(String.format("%-34s %-16s %12d %12.4f %5d", "Inverted Index Lookup", b.bigO, b.comparisons, b.millis, b.products.size()));
        System.out.println(LINE);
        if (a.products.size() != b.products.size()) {
            System.out.println("Note: Inverted Index matches the beginning of each word only (e.g. \"blue\" finds Bluetooth, \"tooth\" does not).");
        }
        System.out.println("Inverted Index results:");
        printTable(b.products);
    }

    private static void doIdSearch() {
        String id = ask("Product ID (e.g. P012): ");
        if (id.isEmpty()) {
            System.out.println("Please enter a product ID.");
            return;
        }
        showResult(idSearch.search(id));
    }

    private static void doFilter() {
        ArrayList<String> names = filter.getCategoryNames(store.getProducts());
        System.out.println("Category:  0. All");
        for (int i = 0; i < names.size(); i++) {
            System.out.println("           " + (i + 1) + ". " + names.get(i));
        }
        int c = readInt("Select category > ", 0, names.size());
        String category = (c == 0) ? CategoryPriceFilter.ALL : names.get(c - 1);

        double min;
        double max;
        while (true) {
            try {
                String a = ask("Min price (Enter = 0): ");
                String b = ask("Max price (Enter = no limit): ");
                min = a.isEmpty() ? 0 : Double.parseDouble(a);
                max = b.isEmpty() ? Double.MAX_VALUE : Double.parseDouble(b);
            } catch (NumberFormatException ex) {
                System.out.println("Invalid price entered.");
                continue;
            }
            if (min > max) {
                System.out.println("Minimum price must not exceed maximum price.");
                continue;
            }
            break;
        }
        showResult(filter.search(category, min, max));
    }

    private static void showAll() {
        printTable(store.getProducts());
        System.out.println("Showing all products: " + store.getProducts().size());
    }

    private static void chooseSort() {
        for (int i = 0; i < SORT_NAMES.length; i++) {
            System.out.println(" " + i + ". " + SORT_NAMES[i] + (i == sortMode ? "   <- current" : ""));
        }
        sortMode = readInt("Select sort > ", 0, SORT_NAMES.length - 1);
        System.out.println("Sort set to: " + SORT_NAMES[sortMode]);
    }

    // ================= Cart =================
    private static void addToCart() {
        String id = ask("Product ID to add (e.g. P011): ");
        if (id.isEmpty()) {
            System.out.println("Please enter a product ID.");
            return;
        }
        // หาสินค้าด้วย Binary Search (IdSearch) แทนการไล่หาทีละตัว
        SearchResult r = idSearch.search(id);
        if (r.products.isEmpty()) {
            System.out.println("Product not found: " + id.toUpperCase());
            return;
        }
        Product p = r.products.get(0);
        int qty = readInt("Quantity (stock " + p.getStock() + "): ", 1, 1000);
        int inCart = cart.containsKey(p) ? cart.get(p) : 0;
        if (inCart + qty > p.getStock()) {
            System.out.println("Out of stock! (stock: " + p.getStock() + ", already in cart: " + inCart + ")");
            return;
        }
        cart.put(p, inCart + qty);
        System.out.println(p.getName() + " x" + qty + " added to cart.   (found with "
                + r.comparisons + " comparisons, " + r.algorithm + ")");
    }

    private static void viewCart() {
        while (true) {
            printCart();
            if (cart.isEmpty()) return;
            String c = ask("[R] Remove item   [C] Clear cart   [B] Back > ").toUpperCase();
            if (c.equals("B")) return;
            if (c.equals("C")) {
                cart.clear();
                System.out.println("Cart cleared.");
            } else if (c.equals("R")) {
                String id = ask("Product ID to remove: ").toUpperCase();
                Product target = null;
                for (Product p : cart.keySet()) {
                    if (p.getId().equals(id)) { target = p; break; }
                }
                if (target == null) {
                    System.out.println("That product is not in the cart.");
                } else {
                    cart.remove(target);
                    System.out.println("Removed " + target.getName() + ".");
                }
            } else {
                System.out.println("Please enter R, C or B.");
            }
            System.out.println();
        }
    }

    private static void printCart() {
        System.out.println("---------------- CART ----------------");
        if (cart.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }
        System.out.println(String.format("%-6s %-32s %9s %4s %12s", "ID", "Product", "Price", "Qty", "Subtotal"));
        System.out.println(LINE);
        double total = 0;
        for (Map.Entry<Product, Integer> e : cart.entrySet()) {
            Product p = e.getKey();
            int qty = e.getValue();
            double sub = p.getPrice() * qty;
            total += sub;
            System.out.println(String.format("%-6s %-32s %,9.0f %4d %,12.2f",
                    p.getId(), p.getName(), p.getPrice(), qty, sub));
        }
        System.out.println(LINE);
        System.out.println(String.format("Total: %,.2f THB", total));
    }

    // ================= Output =================
    private static void showResult(SearchResult r) {
        if (r.products.isEmpty()) {
            System.out.println("No products found.");
        } else {
            printTable(r.products);
        }
        System.out.println();
        System.out.println("  Data structure : " + r.dataStructure);
        System.out.println("  Algorithm      : " + r.algorithm);
        System.out.println("  Big-O          : " + r.bigO);
        System.out.println(String.format("  Results        : %d of %d   |   Comparisons: %d   |   Time: %.4f ms",
                r.products.size(), r.dataSize, r.comparisons, r.millis));
    }

    private static void printTable(ArrayList<Product> list) {
        ArrayList<Product> rows = new ArrayList<>(list);
        Comparator<Product> cmp = null;
        switch (sortMode) {
            case 1: cmp = (a, b) -> Double.compare(a.getPrice(), b.getPrice()); break;
            case 2: cmp = (a, b) -> Double.compare(b.getPrice(), a.getPrice()); break;
            case 3: cmp = (a, b) -> Integer.compare(b.getSold(), a.getSold()); break;
            case 4: cmp = (a, b) -> Double.compare(b.getRating(), a.getRating()); break;
            default: break;
        }
        if (cmp != null) Collections.sort(rows, cmp);

        System.out.println(String.format("%-6s %-32s %-15s %9s %7s %7s %6s",
                "ID", "Product", "Category", "Price", "Rating", "Sold", "Stock"));
        System.out.println(LINE);
        for (Product p : rows) {
            System.out.println(String.format("%-6s %-32s %-15s %,9.0f %7.1f %7d %6d",
                    p.getId(), p.getName(), p.getCategory(), p.getPrice(),
                    p.getRating(), p.getSold(), p.getStock()));
        }
        System.out.println(LINE);
    }
}