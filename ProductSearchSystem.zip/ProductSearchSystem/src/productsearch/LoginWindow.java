package productsearch;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

/** หน้า Login (รูปแบบเดียวกับ Book Management System) */
public class LoginWindow {
    private final JFrame frame;
    private final JTextField txtUser = new JTextField();
    private final JPasswordField txtPass = new JPasswordField();

    public LoginWindow() {
        frame = new JFrame("Product Search System");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JLabel head = new JLabel("Product Search System", SwingConstants.CENTER);
        head.setFont(head.getFont().deriveFont(Font.BOLD, 18f));

        JPanel form = new JPanel(new GridLayout(2, 2, 6, 10));
        form.add(new JLabel("UserID"));
        form.add(txtUser);
        form.add(new JLabel("Password"));
        form.add(txtPass);

        JButton btnLogin = new JButton("Login");

        JPanel root = new JPanel(new BorderLayout(8, 12));
        root.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));
        root.add(head, BorderLayout.NORTH);
        JPanel formWrap = new JPanel(new BorderLayout());
        formWrap.add(form, BorderLayout.NORTH);
        root.add(formWrap, BorderLayout.CENTER);
        root.add(btnLogin, BorderLayout.SOUTH);

        frame.setContentPane(root);
        frame.getRootPane().setDefaultButton(btnLogin); // กด Enter = Login
        frame.setSize(340, 200);
        frame.setLocationRelativeTo(null);

        btnLogin.addActionListener(e -> doLogin());
        frame.setVisible(true);
    }

    private void doLogin() {
        String user = txtUser.getText().trim();
        String pass = new String(txtPass.getPassword());
        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill in your UserID and Password",
                    "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try (Scanner sc = new Scanner(new File("data/users.txt"), "UTF-8")) {
            while (sc.hasNextLine()) {
                String[] p = sc.nextLine().split(",");
                if (p.length == 2 && p[0].trim().equals(user) && p[1].trim().equals(pass)) {
                    frame.dispose();
                    new MainWindow();
                    return;
                }
            }
            JOptionPane.showMessageDialog(frame, "Invalid UserID or Password",
                    "Login Failed", JOptionPane.ERROR_MESSAGE);
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(frame, "Database file not found: data/users.txt",
                    "System Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
