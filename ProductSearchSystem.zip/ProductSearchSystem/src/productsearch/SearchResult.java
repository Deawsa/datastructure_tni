package productsearch;

import java.util.ArrayList;

/** ผลลัพธ์การค้นหา + ข้อมูลสำหรับอธิบายอัลกอริทึมตอนนำเสนอ */
public class SearchResult {
    public final ArrayList<Product> products;
    public final int comparisons;      // จำนวนครั้งที่เปรียบเทียบจริง
    public final double millis;        // เวลาที่ใช้ (มิลลิวินาที)
    public final int dataSize;         // จำนวนข้อมูลทั้งหมด (n)
    public final String dataStructure;
    public final String algorithm;
    public final String bigO;

    public SearchResult(ArrayList<Product> products, int comparisons, long nanos,
                        int dataSize, String dataStructure, String algorithm, String bigO) {
        this.products = products;
        this.comparisons = comparisons;
        this.millis = nanos / 1_000_000.0;
        this.dataSize = dataSize;
        this.dataStructure = dataStructure;
        this.algorithm = algorithm;
        this.bigO = bigO;
    }
}
